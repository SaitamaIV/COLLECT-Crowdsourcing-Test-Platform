from db.my_mysql import Session

def search_all_user():
    session = Session()
    sql = "SELECT * FROM user"
    cursor = session.execute(sql)
    result = cursor.fetchall()
    session.close()
    return result
