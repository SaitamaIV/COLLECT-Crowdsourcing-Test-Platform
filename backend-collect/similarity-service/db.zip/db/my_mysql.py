from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine

url = "mysql+mysqlconnector://root:123456@127.0.0.1:3306/springbootjlvpC"
engine = create_engine(url, pool_size=5)
Session = sessionmaker(bind=engine)